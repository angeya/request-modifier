<script setup lang="ts">
import {ref} from 'vue'
import {updateDynamicRules} from '../api/chromeApi'

interface Rule {
  match: string
  replace: string
  enabled: boolean
  isEditing: boolean
}

const model = ref({
  url: '',
  result: '',
})

const ruleList = ref([
      {
        match: '',
        replace: '',
        enabled: true,
        isEditing: false,
      },
      {
        match: '',
        replace: '',
        enabled: false,
        isEditing: true,
      }
    ] as Rule[]
)
function addRule(): void {
  const rule = {
        match: '',
        replace: '',
        enabled: true,
        isEditing: false,
      }as Rule
  ruleList.value.push(rule)
}
</script>

<template>
  <div class="card" style="width: 600px">
    <n-form-item label="待测试URL" path="url">
      <n-input v-model:value="model.url" placeholder="请输入URL(可输入部分内容)"/>
    </n-form-item>
    <n-form-item label="重定向结果" path="result">
      <n-input v-model:value="model.result" disabled placeholder=""/>
    </n-form-item>
  </div>

  <h4>规则列表</h4>
  <div v-for="(rule, index) in ruleList" :key="index" class="card"
       style="width: 600px; margin: 14px 0; display: flex; gap: 10px; align-items: center;">
    <n-input type="text" class="rule-input" v-model:value="rule.match" placeholder="匹配值，支持正则"/>
    <n-input type="text" class="rule-input" v-model:value="rule.replace" placeholder="替换值"/>
    <n-switch v-model:value="rule.enabled" @update:value=""/>
    <n-button v-if="rule.isEditing" type="success" size="small">保存</n-button>
    <n-button v-else type="warning" size="small">编辑</n-button>
    <n-button type="error" size="small">删除</n-button>
  </div>
  <n-button type="info" @click="addRule">添加规则</n-button>

</template>

<style scoped>

</style>